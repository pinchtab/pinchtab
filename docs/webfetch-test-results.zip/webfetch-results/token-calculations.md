# web_fetch Token Calculation Breakdown

## Estimation Formula

```
Tokens = Text Characters / 4
```

Where:
- **Text only:** Readability-extracted content (no markup overhead)
- Ratio: **4 characters ≈ 1 token** (text-heavy, minimal JSON)

## Per-Site Breakdown

### BBC (18.8 KB)
- Total bytes: 18,800
- All content (Readability already removed structure)
- **Tokens:** 18,800 / 4 = 4,700 tokens
- **Cost (Sonnet):** 4,700 × $3/1M = $0.000014

### Corriere (13.1 KB)
- Total bytes: 13,100
- All content (text-only after Readability)
- **Tokens:** 13,100 / 4 = 3,275 tokens
- **Cost (Sonnet):** 3,275 × $3/1M = $0.000010

### Daily Mail (50 KB, truncated)
- Total bytes: 50,000
- Partial content (web_fetch maxChars limit)
- **Tokens:** 50,000 / 4 = 12,500 tokens
- **Cost (Sonnet):** 12,500 × $3/1M = $0.000038

### Average
- Average bytes: (18.8 + 13.1 + 50) / 3 = 27.3 KB
- Average tokens: (4,700 + 3,275 + 12,500) / 3 = 6,825 tokens
- Average cost: $0.000021 per page

## Comparative Analysis

### vs. Snapshot
| Metric | Snapshot | web_fetch | Ratio |
|--------|----------|-----------|-------|
| BBC Size | 45 KB | 18.8 KB | 2.4x heavier (snapshot) |
| BBC Tokens | 11,250 | 4,700 | 2.4x heavier (snapshot) |
| Corriere Size | 380 KB | 13.1 KB | 29x heavier (snapshot) |
| Corriere Tokens | 95,000 | 3,275 | 29x heavier (snapshot) |
| Daily Mail Size | 350 KB | 50 KB | 7x heavier (snapshot) |
| Daily Mail Tokens | 87,500 | 12,500 | 7x heavier (snapshot) |
| **Average** | **258 KB** | **27.3 KB** | **9.4x heavier (snapshot)** |

### vs. Pinchtab
| Metric | web_fetch | Pinchtab | Ratio |
|--------|-----------|----------|-------|
| Tokens | 6,825 | ~1,200 | 5.7x heavier (web_fetch) |
| Cost | $0.000021 | $0.0000036 | 5.8x more expensive |

## Cost Breakdown

### Single Page Cost
| Method | Tokens | Cost | |
|--------|--------|------|---|
| Snapshot | 64,583 | $0.000194 | 100% |
| **web_fetch** | **6,825** | **$0.000021** | **11%** |
| Pinchtab | 1,200 | $0.0000036 | 1.9% |

### Scale Analysis

**1,000 pages/day:**
- Snapshot: 1,000 × $0.000194 = $0.194/day = **$5.82/month**
- web_fetch: 1,000 × $0.000021 = $0.021/day = **$0.63/month**
- Pinchtab: 1,000 × $0.0000036 = $0.0036/day = **$0.11/month**

**Savings (web_fetch vs. snapshot):**
- Per page: $0.000173 saved
- Per month: $5.19 saved
- Per year: $62.28 saved

**Savings (Pinchtab vs. web_fetch):**
- Per page: $0.000017 saved
- Per month: $0.52 saved
- Per year: $6.24 saved

## Notes

1. **Readability efficiency:** ~70-90% boilerplate removal
2. **No JSON overhead:** web_fetch returns pure text/markdown
3. **Text-heavy ratio:** 4 chars/token (vs. 2 chars/token for JSON)
4. **Daily Mail truncation:** web_fetch has maxChars limit, so actual token count would be higher for full extraction
5. **JavaScript rendering:** NOT included in web_fetch (key limitation)
