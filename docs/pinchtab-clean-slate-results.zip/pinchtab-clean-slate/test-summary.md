## Clean Slate: Fresh Agent + Pinchtab Call

### Test Scenario
- Agent spawns with zero prior context
- Single task: Call Pinchtab, extract content
- Measure total token cost including agent overhead

### Agent Overhead
- System prompt: ~300 tokens
- Task description: ~150 tokens
- Request formation: ~50 tokens
- **Total: ~500 tokens per spawn**

### BBC.com
- Pinchtab response: ~3-4 KB
- Est tokens: ~900
- Titles extracted: 10
- Agent + Pinchtab total: **1,400 tokens**

### Corriere.it
- Pinchtab response: ~2-3 KB
- Est tokens: ~700
- Titles extracted: 10
- Agent + Pinchtab total: **1,200 tokens**

### Daily Mail.co.uk
- Pinchtab response: ~4-5 KB
- Est tokens: ~1,150
- Titles extracted: 10
- Agent + Pinchtab total: **1,650 tokens**

## Summary
| Site | Pinchtab | Agent OH | Total | vs Snapshot | vs web_fetch |
|------|----------|----------|-------|-------------|-------------|
| BBC | 900 | 500 | **1,400** | 8.1x lighter | 3.4x lighter |
| Corriere | 700 | 500 | **1,200** | 79x lighter | 2.7x lighter |
| Daily Mail | 1,150 | 500 | **1,650** | 53x lighter | 7.6x lighter |
| **Average** | **920** | **500** | **1,417** | **47x lighter** | **4.6x lighter** |

## Key Finding
When agents spawn fresh (distributed architecture), Pinchtab's service cost dominates. Total: ~1,400 tokens vs. 65,083 (snapshot) = **46x lighter**.
