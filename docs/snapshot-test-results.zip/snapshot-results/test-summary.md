## BBC - Snapshot Depth 2 Analysis
- Snapshot size: ~45 KB
- Est tokens: ~11,250
- Titles extracted: 17 (limited structural content)
- Sample: [BBC Homepage, Sport headlines, Around the UK, Entertainment and TV, Food and recipes, Insight and analysis, Health and wellbeing, Money, Uplifting stories, The video playlist, Discover more to watch and listen to, New and trending on the BBC, Play today's Sudoku, BBC around the UK, Get support, About the BBC, Best of the BBC]
- Notes: BBC snapshot returns mostly section headings rather than individual article titles

## Corriere - Snapshot Depth 2 Analysis
- Snapshot size: ~380 KB
- Est tokens: ~95,000
- Titles extracted: 20+
- Sample: [La Libia rinuncia all'atomica: il confronto con la Corea del Nord, Iran: ritorna l'Asse con Cina e Russia, Il peso della Champions e quello dell'orgoglio, A Napoli il lago d'Averno si è tinto di rosa, Sanremo, la scaletta: i 15 cantanti, Le pagelle: Gazzoli finto giovane, I voti ai look: Irina Shayk fotonica, Perché il Festival non va: Pausini a disagio, Nicolò Filippucci, vincitore delle Nuove proposte, Chi è Lapo-Ubaldo Pantani, Sei fratelli e il sogno della serenità, Patty Pravo cade dalla sedia, Poche donne al Festival, Legge elettorale, la proposta del centrodestra, I colloqui Usa-Iran tra spiragli e cautela, L'Armada Usa sfida i pasdaran, Il discorso di Trump: dubbi sulla sua salute mentale, Soldati israeliani sparano a un 14enne palestinese, Germania, il tribunale dà ragione all'AfD, Epstein, la deposizione di Hillary Clinton, Parla il papà di Domenico]
- Notes: Extremely comprehensive news coverage with 100+ article titles visible

## Daily Mail - Snapshot Depth 2 Analysis
- Snapshot size: ~350 KB
- Est tokens: ~87,500
- Titles extracted: 20+
- Sample: [EXCLUSIVE Inmate 'who battered Ian Huntley with metal bar' is pictured, Chaos erupts as Hillary Clinton HALTS her Epstein testimony, Starmer faces an anxious wait as polls close, Hidden 'dental pocket' condition plagues HALF of middle-aged people, Trump launches 'Task Force Scorpion' as Iran peace talks collapse, Royal family faces fresh Andrew nightmare, How my happy, healthy daughter became 'possessed', Truth behind terrifying rise of bowel cancer in people under 50, Harry and Meghan 'snubbed' by Jordan's royal family, I've drunk too much for half my life and finally sober, Labour's most wanted: Bangladeshi court orders Interpol Red Notice for Tulip Siddiq, Red Dwarf creator Rob Grant dead at 70, Scientists confirm biblical earthquake during Jesus' crucifixion, Now Peter Mandelson faces EU fraud probe over Epstein files, Piers Morgan brands Jamie Foxx 'shockingly ill-informed', Mother is fined £1,000 for 'fly-tipping' after leaving bag of children's clothes, More than a dozen ministers drafted in to knock doors for Gorton and Denton, Furious Pink denies she's split from husband Carey Hart, Jessie Buckley flashes her underwear in daring sheer corset gown, Christian Bale makes a rare appearance with his wife]
- Notes: Very dense content with 150+ article titles across all categories

## Summary
| Site | Size | Est Tokens | Articles | Density |
|------|------|-----------|----------|---------|
| BBC | 45 KB | ~11,250 | 17 | Low (mostly structure) |
| Corriere | 380 KB | ~95,000 | 100+ | Very High |
| Daily Mail | 350 KB | ~87,500 | 150+ | Very High |

**Key Findings:**
- BBC snapshot is minimal (structured navigation), not suitable for article extraction
- Corriere and Daily Mail return massive snapshots with extensive article listings
- Estimated token overhead: JSON structure ~20-30% of total tokens
- Text-only content efficiency higher on news sites vs BBC portal layout
