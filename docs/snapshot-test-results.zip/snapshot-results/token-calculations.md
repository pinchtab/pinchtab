# Token Calculation Breakdown

## Estimation Formula

```
Tokens = (Text Characters / 4) + (JSON Structure Characters / 2)
```

Where:
- **Text**: article titles, content, labels (human-readable)
- **JSON**: brackets `{}[]`, colons `:`, quotes `"`, commas `,`

## Per-Site Breakdown

### BBC (45 KB)
- Total bytes: 45,000
- Estimated text content: ~60% = 27,000 chars
- Estimated JSON structure: ~40% = 18,000 chars
- **Text tokens:** 27,000 / 4 = 6,750
- **Structure tokens:** 18,000 / 2 = 9,000
- **Total: ~15,750 tokens** (estimate: ~11,250 based on content density)

### Corriere (380 KB)
- Total bytes: 380,000
- Estimated text content: ~70% = 266,000 chars
- Estimated JSON structure: ~30% = 114,000 chars
- **Text tokens:** 266,000 / 4 = 66,500
- **Structure tokens:** 114,000 / 2 = 57,000
- **Total: ~123,500 tokens** (estimate: ~95,000 based on observed titles)

### Daily Mail (350 KB)
- Total bytes: 350,000
- Estimated text content: ~70% = 245,000 chars
- Estimated JSON structure: ~30% = 105,000 chars
- **Text tokens:** 245,000 / 4 = 61,250
- **Structure tokens:** 105,000 / 2 = 52,500
- **Total: ~113,750 tokens** (estimate: ~87,500 based on observed titles)

## Comparative Token Ratios

### web_fetch (Readability extraction)
- BBC: 18.8 KB → ~4,700 tokens
- Corriere: 13.1 KB → ~3,275 tokens
- Daily Mail: 50 KB (truncated) → ~12,500 tokens

**vs. Snapshot:**
- BBC: 11,250 / 4,700 = **2.4x heavier**
- Corriere: 95,000 / 3,275 = **29x heavier**
- Daily Mail: 87,500 / 12,500 = **7x heavier**
- **Average: 12.8x heavier with full snapshot**

### Pinchtab /text (estimated)
- Assuming minimal JSON overhead (~200 bytes)
- ~1,000-1,500 tokens per page

**vs. Snapshot:**
- BBC: 11,250 / 1,000 = **11.25x heavier**
- Corriere: 95,000 / 1,200 = **79x heavier**
- Daily Mail: 87,500 / 1,200 = **73x heavier**
- **Average: 54x heavier with full snapshot**

## Cost Breakdown (Sonnet @ $3/M tokens)

### Single Request Cost
| Method | Tokens | Cost | Monthly (1K pages) |
|--------|--------|------|-------------------|
| Snapshot | ~64,583 | $0.000194 | $5.82 |
| web_fetch | ~6,825 | $0.000021 | $0.63 |
| Pinchtab | ~1,200 | $0.0000036 | $0.11 |

### Cumulative Savings
- **Pinchtab vs. Snapshot:** 98.1% token reduction
- **Pinchtab vs. web_fetch:** 82.4% additional reduction
- **web_fetch vs. Snapshot:** 89.4% reduction

## Notes

1. **web_fetch** readability extraction removes navigation, ads, structured markup
2. **Pinchtab** targets main content via CSS selectors (optional filtering)
3. **Snapshot** includes full DOM = highest fidelity, highest tokens
4. Actual tokens depend on page complexity and DOM nesting depth
